#!/usr/bin/bash

make clean
make all
./mypool
