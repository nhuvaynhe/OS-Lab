#!/usr/bin/bash

make clean
make all
time ./mypool
