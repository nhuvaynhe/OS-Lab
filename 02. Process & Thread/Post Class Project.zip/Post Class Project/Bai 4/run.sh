make clean
make all

./mmap_send

./mmap_receive
