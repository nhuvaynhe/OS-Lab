#!/usr/bin/bash

make clean
make node_2
 
./node_2