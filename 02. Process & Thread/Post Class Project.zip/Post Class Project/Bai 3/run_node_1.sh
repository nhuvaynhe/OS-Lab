#!/usr/bin/bash

make clean
make node_1

./node_1